-- ================================
-- 📦 ATLAS SETUP
-- ================================
SMODS.Atlas {
    key = "ModdedVanilla",
    path = "ModdedVanilla.png",
    px = 71,
    py = 95
}
SMODS.Atlas {
    key = "coolmod",
    path = "cool mod.png",
    px = 71,
    py = 95
}
SMODS.Atlas {
    key = "forsaken",
    path = "forsaken.png",
    px = 71,
    py = 95
}
SMODS.Atlas {
    key = "slateskin",
    path = "slateskin.png",
    px = 71,
    py = 95
}


SMODS.Joker {
	key = 'papyrus_tile',
	loc_txt = {
		name = 'Papyrus Tiles',
		text = {
			"Get {C:attention}randomized mult{}"
		}
	},
	config = { 
		extra = { mult = 3 }
	},
	rarity = 1,
	atlas = 'ModdedVanilla',  -- ✅ change to the base Joker atlas
	pos = { x = 0, y = 0 },
	cost = 4,

	loc_vars = function(self, info_queue, card)
		return { vars = {} }
	end,

	calculate = function(self, card, context)
		if context.joker_main then
			return {
				mult_mod = card.ability.extra.mult,
				message = localize { 
					type = 'variable', 
					key = 'a_mult', 
					vars = { "???" }
				}
			}
		end
	end
}


SMODS.Joker {
    key = 'stick',
    loc_txt = {
        name = 'Stick',
        text = {
            "Holy shit it's Stick"
        }
    },
    config = {
        extra = {
            mult = 1,
            chips = 0,
            timer = 0
        }
    },
    rarity = 4,
    atlas = 'ModdedVanilla',
    pos = { x = 1, y = 0 },
    cost = 10,

    -- Tooltip stays mysterious
    loc_vars = function(self, info_queue, card)
        return { vars = { "???" } }
    end,

    -- Randomizes mult and chips every second
    update = function(self, card, dt)
        card.ability.extra.timer = (card.ability.extra.timer or 0) + dt
        if card.ability.extra.timer >= 1 then
            card.ability.extra.timer = 0

            -- Randomize stats
            card.ability.extra.mult = math.random(0, 10)
            card.ability.extra.chips = math.random(0, 200)
        end
    end,

    -- Applies the random stats during scoring
    calculate = function(self, card, context)
        if context.joker_main then
            return {
                mult_mod = card.ability.extra.mult,
                chip_mod = card.ability.extra.chips,
                message = localize {
                    type = 'variable',
                    key = 'a_mult',
                    vars = { "???" }
                }
            }
        end
    end
}

SMODS.Joker {
    key = 'ai_code',
    loc_txt = {
        name = 'A.I. Code',
        text = {
            "50% chance to give {C:mult}+50{} Mult,",
            "or {C:mult}-50{} Mult"
        }
    },
    config = {
        extra = {
            mult_bonus = 50
        }
    },
    rarity = 4,
    atlas = 'ModdedVanilla',
    pos = { x = 2, y = 0 },
    cost = 8,

    calculate = function(self, card, context)
        if context.joker_main then
            local roll = math.random() < 0.5
            local mult = card.ability.extra.mult_bonus * (roll and 1 or -1)
            local symbol = roll and "50" or "50"
            local color = roll and "positive" or "negative"

            return {
                mult_mod = mult,
                message = localize {
                    type = 'variable',
                    key = 'a_mult',
                    vars = { symbol }
                },
                colour = G.C[color]  -- Optional: uses built-in color for message (green/red)
            }
        end
    end
}

SMODS.Joker {
    key = 'resolution_joker',
    loc_txt = {
        name = 'YOU GOT ANYMORE OF THEM PIXELS',
        text = {
            "Gain {C:mult}Mult{} based on screen resolution"
        }
    },
    config = {
        extra = {
            mult = 0,
            timer = 0
        }
    },
    rarity = 4,
    atlas = 'ModdedVanilla',
    pos = { x = 3, y = 0 },
    cost = 10,

    -- Update mult based on resolution every second
    update = function(self, card, dt)
        card.ability.extra.timer = (card.ability.extra.timer or 0) + dt
        if card.ability.extra.timer >= 1 then
            card.ability.extra.timer = 0

            -- Get screen width and height
            local w, h = love.graphics.getWidth(), love.graphics.getHeight()

            -- Scale multiplier: every 1000x1000 = +10 Mult (tune to taste)
            local scale = (w * h) / 100000
            card.ability.extra.mult = math.floor(scale)
        end
    end,

    -- Apply multiplier during scoring
    calculate = function(self, card, context)
        if context.joker_main then
            local mult = card.ability.extra.mult or 0
            return {
                mult_mod = mult,
                message = localize {
                    type = 'variable',
                    key = 'a_mult',
                    vars = { tostring(mult) }
                }
            }
        end
    end,

    -- Show the current multiplier in tooltip
    loc_vars = function(self, info_queue, card)
        return { vars = { tostring(card.ability.extra.mult or 0) } }
    end
}

SMODS.Joker {
    key = 'papaya',
    loc_txt = {
        name = 'Papaya',
        text = {
            "{C:mult}+5{} Mult, plus {C:mult}+1{} Mult",
            "for each other Papaya you have",
            "(max {C:mult}+15{})"
        }
    },
    config = {
        extra = {
            base_mult = 5,
            per_papaya = 1,
            max_mult = 15
        }
    },
    rarity = 2,
    atlas = 'ModdedVanilla',
    pos = { x = 4, y = 0 },
    cost = 6,

    -- Calculate total Mult
    calculate = function(self, card, context)
        if context.joker_main then
            local base = card.ability.extra.base_mult
            local bonus = 0

            -- Count all other Papaya cards
            local count = 0
            for _, c in pairs(G.jokers.cards) do
                if c ~= card and c.key == 'papaya' then
                    count = count + 1
                end
            end

            bonus = card.ability.extra.per_papaya * count
            local total = math.min(base + bonus, card.ability.extra.max_mult)

            return {
                mult_mod = total,
                message = localize {
                    type = 'variable',
                    key = 'a_mult',
                    vars = { "+" .. tostring(total) }
                }
            }
        end
    end,

    -- Show current value in tooltip
    loc_vars = function(self, info_queue, card)
        local base = card.ability.extra.base_mult
        local bonus = 0
        local count = 0
        if G and G.jokers and G.jokers.cards then
            for _, c in pairs(G.jokers.cards) do
                if c ~= card and c.key == 'papaya' then
                    count = count + 1
                end
            end
            bonus = card.ability.extra.per_papaya * count
        end
        local total = math.min(base + bonus, card.ability.extra.max_mult)
        return { vars = { tostring(total) } }
    end
}

SMODS.Joker {
    key = 'brumberg_astromancer',
    loc_txt = {
        name = 'Victor Brumberg',
        text = {
            "Gains Mult relative to number of rounds passed",
            "I got him out of a randomized wikipedia article"
        }
    },
    config = {
        extra = {
            base_mult = 5,
            per_round = 2,
            penalty_factor = 0.5  -- fraction applied to opponent if misaligned
        }
    },
    rarity = 4,
    atlas = 'ModdedVanilla',
    pos = { x = 5, y = 0 },
    cost = 9,

    calculate = function(self, card, context)
        if context.joker_main then
            local rounds = context.round or 0
            local bonus = card.ability.extra.per_round * rounds
            local total = card.ability.extra.base_mult + bonus

            -- maybe cap it so it doesn't go infinite
            total = math.min(total, 50)

            -- Optionally penalize opponent if conditions
            local opponent_penalty = 0
            if context.joker_opponent then
                -- If opponent’s mult is “out of sync”, reduce theirs
                local opp_mult = context.joker_opponent.mult or 0
                local ideal = total  -- alignment target
                local diff = math.abs(opp_mult - ideal)
                opponent_penalty = math.floor(diff * card.ability.extra.penalty_factor)
            end

            return {
                mult_mod = total,
                opp_mult_mod = -opponent_penalty,
                message = localize {
                    type = 'variable',
                    key = 'a_mult',
                    vars = { "+" .. tostring(total) }
                }
            }
        end
    end,

    -- optionally show value in tooltip
    loc_vars = function(self, info_queue, card)
        local rounds = 0
        if G and G.round then rounds = G.round end
        local value = card.ability.extra.base_mult + (card.ability.extra.per_round * rounds)
        value = math.min(value, 50)
        return { vars = { tostring(value) } }
    end
}
SMODS.Joker {
    key = 'youre_winner',
    loc_txt = {
        name = "you're winner",
        text = {
            "Has a {C:attention}1 in 10,000{} chance",
            "to grant {C:mult}+ 99999999999999{} Mult when scoring."
        }
    },
    config = {
        extra = {
            chance = 10000,
            jackpot_mult = 99999999999999
        }
    },
    rarity = 1,
    atlas = 'ModdedVanilla',
    pos = { x = 0, y = 1 },
    cost = 10,

    calculate = function(self, card, context)
        if context.joker_main then
            local roll = pseudorandom("yourewinner", 1, card.ability.extra.chance)
            if roll == 1 then
                -- 🎉 JACKPOT! Huge Mult bonus
                return {
                    mult_mod = card.ability.extra.jackpot_mult,
                    message = "WINNER!!",
                    colour = G.C.GREEN
                }
            else
                -- Most of the time, does nothing
                return nil
            end
        end
    end
}
SMODS.Joker {
    key = 'coupon_100',
    loc_txt = {
        name = "100% Coupon",
        text = {
            "Gives you {C:attention}99999999{} dollars.",
        }
    },
    config = {
        extra = { mult_given = 0 }
    },
    rarity = 1,
    atlas = 'ModdedVanilla',
    pos = { x = 1, y = 1 },
    cost = 4,

    calculate = function(self, card, context)
        if context.joker_main then
            return {
                mult_mod = card.ability.extra.mult_given,
                message = "Fuck you. You get nothing."
            }
        end
    end
}
SMODS.Joker {
    key = 'cement',
    loc_txt = {
        name = 'Cement',
        text = {
            "Gives {C:mult}+6{} Mult",
            "Decreases by {C:red}-1{} each round"
        }
    },
    config = { extra = { mult = 6 } },
    rarity = 1,
    atlas = 'ModdedVanilla',
    pos = { x = 3, y = 1 },
    cost = 4,

    calculate = function(self, card, context)
        if context.joker_main then
            return { mult_mod = card.ability.extra.mult }
        elseif context.end_of_round and not context.blueprint then
            card.ability.extra.mult = math.max(card.ability.extra.mult - 1, 0)
        end
    end
}


-- ✅ Safer Artful Joker (won’t crash if Cement doesn’t exist)
SMODS.Joker {
    key = 'artful',
    loc_txt = {
        name = 'Artful',
        text = {
            "{C:attention}50%{} chance to create a {C:attention}Cement{} Joker,",
            "otherwise, do nothing"
        }
    },
    rarity = 3,
    atlas = 'ModdedVanilla',
    pos = { x = 2, y = 1 },
    cost = 8,

    calculate = function(self, card, context)
        if context.joker_main then
            if pseudorandom('artful') < 0.5 then
                if #G.jokers.cards < G.jokers.config.card_limit then
                    -- ✅ Safe lookup for Cement card
                    local cement_center = G.P_CENTERS['j_mvan_cement'] or G.P_CENTERS['cement']
                    
                    if cement_center then
                        local cement = create_card('Joker', G.jokers, nil, nil, nil, nil, cement_center.key)
                        cement:add_to_deck()
                        G.jokers:emplace(cement)
                        return { message = "Cement Created!", colour = G.C.GREEN }
                    else
                        print("⚠️ Cement card not found in G.P_CENTERS!")
                        return { message = "Cement Missing!", colour = G.C.RED }
                    end
                else
                    return { message = "No Space!", colour = G.C.RED }
                end
            else
                return { message = "Nothing Happens...", colour = G.C.RED }
            end
        end
    end
}

SMODS.Shader({ key = 'anaglyphic', path = 'anaglyphic.fs' })
SMODS.Shader({ key = 'flipped', path = 'flipped.fs' })
SMODS.Shader({ key = 'fluorescent', path = 'fluorescent.fs' })
-- SMODS.Shader({key = 'gilded', path = 'gilded.fs'})
SMODS.Shader({ key = 'greyscale', path = 'greyscale.fs' })
-- SMODS.Shader({key = 'ionized', path = 'ionized.fs'})
-- SMODS.Shader({key = 'laminated', path = 'laminated.fs'})
-- SMODS.Shader({key = 'monochrome', path = 'monochrome.fs'})
SMODS.Shader({ key = 'overexposed', path = 'overexposed.fs' })
-- SMODS.Shader({key = 'sepia', path = 'sepia.fs'})

SMODS.Edition({
    key = "flipped",
    loc_txt = {
        name = "Flipped",
        label = "Flipped",
        text = {
            "nothin"
        }
    },
    -- Stop shadow from being rendered under the card
    disable_shadow = true,
    -- Stop extra layer from being rendered below the card.
    -- For edition that modify shape or transparency of the card.
    disable_base_shader = true,
    shader = "flipped",
    discovered = true,
    unlocked = true,
    config = {},
    in_shop = true,
    weight = 8,
    extra_cost = 6,
    apply_to_float = true,
    loc_vars = function(self)
        return { vars = {} }
    end
})

SMODS.Edition({
    key = "greyscale",
    loc_txt = {
        name = "Greyscale",
        label = "Greyscale",
        text = {
            "{C:chips}+#1#{} chips, {C:mult}+#2#{} Mult",
            "and {X:mult,C:white}X#3#{} Mult"
        }
    },

    shader = "greyscale",
    discovered = true,
    unlocked = true,
    config = { chips = 200, mult = 10, x_mult = 2 },
    in_shop = true,
    weight = 8,
    extra_cost = 6,
    apply_to_float = true,
    loc_vars = function(self)
        return { vars = { self.config.chips, self.config.mult, self.config.x_mult } }
    end
})

SMODS.Edition({
    key = "fluorescent",
    loc_txt = {
        name = "Fluorescent",
        label = "Fluorescent",
        text = {
            "Earn {C:money}$#1#{} when this",
            "card is scored"
        }
    },
    discovered = true,
    unlocked = true,
    shader = 'fluorescent',
    config = { p_dollars = 3 },
    in_shop = true,
    weight = 8,
    extra_cost = 4,
    apply_to_float = true,
    loc_vars = function(self)
        return { vars = { self.config.p_dollars } }
    end
})

SMODS.Edition({
    key = "anaglyphic",
    loc_txt = {
        name = "Anaglyphic",
        label = "Anaglyphic",
        text = {
            "{C:chips}+#1#{} Chips",
            "{C:red}+#2#{} Mult"
        }
    },
    discovered = true,
    unlocked = true,
    shader = 'anaglyphic',
    config = { chips = 10, mult = 4 },
    in_shop = true,
    weight = 8,
    extra_cost = 4,
    apply_to_float = true,
    loc_vars = function(self)
        return { vars = { self.config.chips, self.config.mult } }
    end
})

SMODS.Edition({
    key = "overexposed",
    loc_txt = {
        name = "Overexposed",
        label = "Overexposed",
        text = {
            "{C:green}Retrigger{} this card"
        }
    },
    discovered = true,
    unlocked = true,
    shader = 'overexposed',
    config = { repetitions = 1 },
    in_shop = true,
    weight = 8,
    extra_cost = 4,
    apply_to_float = true,
    loc_vars = function(self)
        return {}
    end
})

SMODS.Seal {
    name = "Fake",
    key = "blu",
    badge_colour = HEX("7b542d"),
	config = { mult = -5, chips = -20, money = -1, x_mult = -1.5  },
    loc_txt = {
        -- Badge name (displayed on card description when seal is applied)
        label = 'Fake Seal',
        -- Tooltip description
        name = 'Fake Seal',
        text = {
            '{C:mult}#1#{} Mult',
            '{C:chips}#2#{} Chips',
            '{C:money}$#3#{}',
            '{X:mult,C:white}X#4#{} Mult',
        }
    },
    loc_vars = function(self, info_queue)
        return { vars = {self.config.mult, self.config.chips, self.config.money, self.config.x_mult, } }
    end,
    atlas = "seal_atlas",
    pos = {x=0, y=0},

    -- self - this seal prototype
    -- card - card this seal is applied to
    calculate = function(self, card, context)
        -- main_scoring context is used whenever the card is scored
        if context.main_scoring and context.cardarea == G.play then
            return {
                mult = self.config.mult,
                chips = self.config.chips,
                dollars = self.config.money,
                x_mult = self.config.x_mult
            }
        end
    end,
}

SMODS.Atlas {
    key = "seal_atlas",
    path = "modded_seal.png",
    px = 71,
    py = 95
}

SMODS.Spectral {
    key = "fake_seal",
    loc_txt = {
        name = "Fake Seal",
        text = {
            "Apply a {C:attention}Fake Seal{} to a selected card"
        }
    },
    atlas = "ModdedVanilla",
    pos = { x = 4, y = 1 },
    cost = 4,

    can_use = function(self, card)
        -- You can use this if there are cards to pick from
        return (#G.hand.cards > 0 or #G.jokers.cards > 0)
    end,

    use = function(self, card)
        G.E_MANAGER:add_event(Event({
            func = function()
                G.STATE = G.STATES.SELECTING
                G.SELECTING = {
                    message = "Select a card to give a Fake Seal",
                    action = function(target)
                        if target then
                            -- Manually apply the seal safely
                            target.seal = "blu"
                            target.T.seal = nil -- clear existing seal texture cache
                            target:set_seal("blu", nil, true) -- force refresh
                            play_sound("generic1")
                            target:juice_up(0.8, 0.8)
                            G.GAME:toast("Applied {C:attention}Fake Seal{} to " .. (target.ability.name or "card") .. "!")
                        else
                            G.GAME:toast("No card selected.")
                        end
                    end,
                    filter = function(card)
                        -- Only allow cards that can have seals (hand or jokers)
                        return card.ability and (card.area == G.hand or card.area == G.jokers)
                    end
                }
                return true
            end
        }))
    end
}
SMODS.Back{
    name = "15 Deck",
    key = "cardboard",
    atlas = "ModdedVanilla",
    pos = {x = 5, y = 1},
    loc_txt = {
        name = "15 Deck",
        text = {"Joker slots are 15"}
    },
    apply = function(self)
        G.E_MANAGER:add_event(Event({
            func = function()
                G.jokers.config.card_limit = 15
                print("[Cardboard Deck] Joker slots increased to 15")
                return true
            end
        }))
    end
}
SMODS.Joker{
    key = "bear5",
    atlas = "ModdedVanilla", -- or "Stuffs" if you prefer your new atlas
    pos = {x = 0, y = 2},
    rarity = 3,
    cost = 8,
    config = {extra = {timer = 30, dead = false}},
    loc_txt = {
        name = "Bear5",
        text = {
            "Gives {C:mult}+555{} Mult.",
            "But has a 30 second timer before destroying itself."
        }
    },
    blueprint_compat = false,

    calculate = function(self, card, context)
        if context.joker_main then
            return {
                mult = 555,
                message = "BEAR5",
                colour = G.C.BLUE
            }
        end
    end,

    update = function(self, card, dt)
        -- Decrease timer in real time
        if not card.ability.extra.dead then
            card.ability.extra.timer = card.ability.extra.timer - dt

            -- Optional visual flashing when low
            if card.ability.extra.timer < 10 and math.floor(card.ability.extra.timer * 2) % 2 == 0 then
                card.highlighted = true
            else
                card.highlighted = false
            end

            -- Detonate!
            if card.ability.extra.timer <= 0 then
                card.ability.extra.dead = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        play_sound('explosion')
                        -- Massive mult penalty
                        G.GAME.perma_mult = (G.GAME.perma_mult or 0) - 99999999
                        card:start_dissolve()
                        return true
                    end
                }))
            end
        end
    end
}
SMODS.Joker{
    key = "fatal_misprint",
    atlas = "ModdedVanilla",
    pos = {x = 0.5, y = 1.5},
    rarity = 3,
    cost = 6,
    config = {extra = {}},
    loc_txt = {
        name = "Fatal Misprint",
        text = {
            "Gives a {C:attention}random Mult{} each round,",
        }
    },
    blueprint_compat = false,

    calculate = function(self, card, context)
        if context.joker_main then
            local roll = math.random(-500, 500)
            local color = roll >= 0 and G.C.MULT or G.C.RED
            return {
                mult = roll,
                message = tostring(roll),
                colour = color
            }
        end
    end
}
SMODS.Joker {
    key = 'baldi',
    loc_txt = {
        name = 'Baldi',
        text = {
            "{C:attention}50%{} chance to create a {C:attention}Baldloon{} Joker,",
            "otherwise, do nothing"
        }
    },
    rarity = 3,
    atlas = 'ModdedVanilla',
    pos = { x = 1, y = 2 },
    cost = 10,

    calculate = function(self, card, context)
        if context.joker_main then
            if pseudorandom('baldi') < 0.5 then
                if #G.jokers.cards < G.jokers.config.card_limit then
                    -- ✅ Safe lookup for Baldloon
                    local baldloon_center = G.P_CENTERS['j_mvan_baldloon'] or G.P_CENTERS['baldloon']

                    if baldloon_center then
                        local baldloon = create_card('Joker', G.jokers, nil, nil, nil, nil, baldloon_center.key)
                        baldloon:add_to_deck()
                        G.jokers:emplace(baldloon)
                        play_sound('generic1')
                        return { message = "BALDLOON!", colour = G.C.GREEN }
                    else
                        print("⚠️ Baldloon card not found in G.P_CENTERS!")
                        return { message = "Missing Baldloon!", colour = G.C.RED }
                    end
                else
                    return { message = "No Space!", colour = G.C.RED }
                end
            else
                return { message = "Nothing Happens...", colour = G.C.RED }
            end
        end
    end
}

-- BALDLOON
SMODS.Joker{
    key = "baldloon",
    atlas = "ModdedVanilla",
    pos = {x = 2, y = 2},
    rarity = 1,
    cost = 0,
    loc_txt = {
        name = "Baldloon",
        text = {
            "Gives random {C:mult}Mult{} between {C:red}-10{} and {C:mult}+15{}.",
        }
    },
    blueprint_compat = false,

    calculate = function(self, card, context)
        if context.joker_main then
            local roll = math.random(-10, 15)
            local color = roll >= 0 and G.C.MULT or G.C.RED
            return {
                mult = roll,
                message = tostring(roll),
                colour = color
            }
        end
    end,

    update = function(self, card, dt)
        if G.STATE == G.STATES.END_ROUND then
            G.E_MANAGER:add_event(Event({
                func = function()
                    card:start_dissolve()
                    return true
                end
            }))
        end
    end
}
SMODS.Joker {
    key = 'goku',
    loc_txt = {
        name = 'Goku',
        text = {
            "This card is gives {C:mult}+ 999 mult{}",
            "{C:chips}+ 999999999 chips{}",
            "and adds {C:mult}+ 9999 mult to itself every round{}",
        }
    },
    rarity = 4,
    atlas = 'ModdedVanilla',
    pos = { x = 3, y = 2 },
    cost = 20,

    calculate = function(self, card, context)
        if context.joker_main then
            return {
                mult = 1,
                message = "Power Overwhelming!",
                colour = G.C.YELLOW
            }
        end
    end
}
-------------------------
-- 🃏 COOLMOD JOKERS PACK
-------------------------

-- Helper for safe random checks
local function rand(p)
    return pseudorandom(p)
end

-- Helper to safely spawn jokers
local function safe_spawn_joker(center_key)
    local center = G.P_CENTERS[center_key]
    if center and #G.jokers.cards < G.jokers.config.card_limit then
        local j = create_card('Joker', G.jokers, nil, nil, nil, nil, center.key)
        j:add_to_deck()
        G.jokers:emplace(j)
        return true
    end
    return false
end

-------------------------
-- Ancient Ass Clock
-------------------------
SMODS.Joker {
    key = 'ancient_ass_clock',
    atlas = 'coolmod',
    pos = {x = 0, y = 0},
    rarity = 2,
    cost = 7,
    loc_txt = {
        name = "Ancient Ass Clock",
        text = {
            "Sets Mult equal to rounds played",
            "at end of each round."
        }
    },
    calculate = function(self, card, context)
        if context.end_of_round then
            G.GAME.perma_mult = (G.GAME.rounds or 1)
            play_sound('clock_tick')
            return {message = "Tick Tock", colour = G.C.GREEN}
        end
    end
}

-------------------------
-- Matthew Patthew
-------------------------
SMODS.Joker {
    key = 'matthew_patthew',
    atlas = 'coolmod',
    pos = {x = 1, y = 0},
    rarity = 2,
    cost = 6,
    loc_txt = {
        name = "Matthew Patthew",
        text = {
            "50% chance to double Chips",
            "or reset Mult to 0"
        }
    },
    calculate = function(self, card, context)
        if context.joker_main then
            if rand('matthew') < 0.5 then
                return {xchips = 2, message = "Blessed", colour = G.C.BLUE}
            else
                G.GAME.perma_mult = 0
                return {message = "Cursed", colour = G.C.RED}
            end
        end
    end
}

-------------------------
-- Nothing
-------------------------
SMODS.Joker {
    key = 'nothing',
    atlas = 'coolmod',
    pos = {x = 2, y = 0},
    rarity = 1,
    cost = 2,
    loc_txt = {
        name = "Nothing",
        text = {"Does absolutely nothing."}
    },
    calculate = function() end
}

-------------------------
-- Smiley
-------------------------
SMODS.Joker {
    key = 'smiley',
    atlas = 'coolmod',
    pos = {x = 3, y = 0},
    rarity = 2,
    cost = 5,
    loc_txt = {
        name = "Smiley",
        text = {
            "Lose $1 but gain +2 Mult each hand"
        }
    },
    calculate = function(self, card, context)
        if context.joker_main then
            ease_dollars(-1)
            return {mult = 2, message = ":)", colour = G.C.YELLOW}
        end
    end
}

-------------------------
-- Hangman
-------------------------
SMODS.Joker {
    key = 'hangman',
    atlas = 'coolmod',
    pos = {x = 4, y = 0},
    rarity = 3,
    cost = 6,
    config = {extra = {mult = 20}},
    loc_txt = {
        name = "Hangman",
        text = {
            "Starts with +20 Mult.",
            "Loses 5 Mult each hand.",
            "Dies when it reaches 0."
        }
    },
    calculate = function(self, card, context)
        if context.joker_main then
            local extra = card.ability.extra
            if extra.mult <= 0 then
                card:start_dissolve()
                return {message = "Hung!", colour = G.C.RED}
            end
            extra.mult = extra.mult - 5
            return {mult = extra.mult}
        end
    end
}

-------------------------
-- Discord
-------------------------
SMODS.Joker {
    key = 'discord',
    atlas = 'coolmod',
    pos = {x = 5, y = 0},
    rarity = 2,
    cost = 4,
    loc_txt = {
        name = "Discord",
        text = {
            "10% chance to add a random Common Joker",
            "every hand."
        }
    },
    calculate = function(self, card, context)
        if context.joker_main and rand('discord') < 0.1 then
            local commons = {}
            for k,v in pairs(G.P_CENTERS) do
                if v.set == 'Joker' and v.rarity == 1 then
                    table.insert(commons, v)
                end
            end
            if #commons > 0 then
                local pick = commons[math.random(#commons)]
                safe_spawn_joker(pick.key)
                play_sound('coin3')
                return {message = "New Joker!", colour = G.C.BLUE}
            end
        end
    end
}

-------------------------
-- Stock Photo Man
-------------------------
SMODS.Joker {
    key = 'stock_photo_man',
    atlas = 'coolmod',
    pos = {x = 0, y = 1},
    rarity = 2,
    cost = 7,
    loc_txt = {
        name = "Stock Photo Man",
        text = {
            "Doubles Mult of all Common Jokers.",
            "Triples if you have Smiley."
        }
    },
    calculate = function(self, card, context)
        if context.joker_main then
            local mult = 2
            if next(find_joker('smiley')) then mult = 3 end
            return {xmult = mult, message = "Motivated!", colour = G.C.MONEY}
        end
    end
}

-------------------------
-- Mario Chuffin A Fat One
-------------------------
SMODS.Joker {
    key = 'mario_chuffin',
    atlas = 'coolmod',
    pos = {x = 1, y = 1},
    rarity = 3,
    cost = 8,
    loc_txt = {
        name = "Mario Chuffin A Fat One",
        text = {
            "+420 Chips per hand.",
            "10% chance to destroy a random Joker."
        }
    },
    calculate = function(self, card, context)
        if context.joker_main then
            if rand('mario') < 0.1 and #G.jokers.cards > 1 then
                local victim = pseudorandom_element(G.jokers.cards, pseudoseed('mario'))
                if victim and victim ~= card then victim:start_dissolve() end
                return {xchips = 1, message = "Mamma Mia!", colour = G.C.RED}
            end
            return {chips = 420}
        end
    end
}

-------------------------
-- Ralsei Chuffin A Fat One
-------------------------
SMODS.Joker {
    key = 'ralsei_chuffin',
    atlas = 'coolmod',
    pos = {x = 2, y = 1},
    rarity = 3,
    cost = 8,
    loc_txt = {
        name = "Ralsei Chuffin A Fat One",
        text = {
            "+69 Mult but disables all other jokers."
        }
    },
    calculate = function(self, card, context)
        if context.joker_main then
            for _, j in ipairs(G.jokers.cards) do
                if j ~= card then j.ability.disabled = true end
            end
            return {mult = 69}
        end
    end
}

-------------------------
-- Hello Ralsei From Deltarune Hello Mario From Super Mario 64
-------------------------
SMODS.Joker {
    key = 'hello_ralsei_mario',
    atlas = 'coolmod',
    pos = {x = 3, y = 1},
    rarity = 3,
    cost = 10,
    loc_txt = {
        name = "Hello Ralsei From Deltarune Hello Mario From Super Mario 64",
        text = {
            "If Mario & Ralsei are in play, gain +999 Chips and +99 Mult.",
            "Otherwise, does nothing."
        }
    },
    calculate = function(self, card, context)
        if context.joker_main then
            if next(find_joker('mario_chuffin')) and next(find_joker('ralsei_chuffin')) then
                return {chips = 999, mult = 99, message = "Perfect Combo!", colour = G.C.PURPLE}
            end
        end
    end
}

-------------------------
-- Roblox Private Server (3 cards)
-------------------------
for i=1,3 do
    SMODS.Joker {
        key = 'roblox_private_server_'..i,
        atlas = 'coolmod',
        pos = {x = (i-1), y = 2},
        rarity = 2,
        cost = 5,
        loc_txt = {
            name = "Roblox Private Server "..i,
            text = {
                "Part of a 3-card set.",
                "All 3: +777 Mult | 1-2: Lose $7/round."
            }
        },
        calculate = function(self, card, context)
            if context.end_of_round then
                local count = 0
                for j=1,3 do if next(find_joker('roblox_private_server_'..j)) then count = count + 1 end end
                if count == 3 then
                    G.GAME.perma_mult = (G.GAME.perma_mult or 0) + 777
                    return {message = "Server Full!", colour = G.C.GREEN}
                else
                    ease_dollars(-7)
                    return {message = "Server Empty...", colour = G.C.RED}
                end
            end
        end
    }
end

-------------------------
-- Auto Clicker
-------------------------
SMODS.Joker {
    key = 'auto_clicker',
    atlas = 'coolmod',
    pos = {x = 3, y = 2},
    rarity = 3,
    cost = 9,
    loc_txt = {
        name = "Auto Clicker",
        text = {
            "Automatically plays hands.",
            "+1 Mult per card played automatically."
        }
    },
    calculate = function(self, card, context)
        if context.joker_main then
            return {mult = #G.play.cards}
        end
    end
}
SMODS.Joker{
    key = 'noob_song',
    atlas = 'coolmod',
    pos = {x = 4, y = 2},
    rarity = 2,
    cost = 9,
    loc_txt = {
        name = "Noob Song",
        text = {
            "Gives {C:mult}+760 Mult{}",
        }
    },
    config = {extra = {mult = 760}},

    calculate = function(self, card, context)
        if context.joker_main then
            local lyrics = {
                "Living life in a life of a noob",
                "I rarely use my gun",
                "Living life in a life of a noob",
                "It's fun for everyone",
                "Living life in a life of a noob",
                "I watch the rising sun",
                "Living life in a life of a noob",
                "I'm always on the run",

                "I just got this game yesterday",
                "So I don't know where to go",
                "Can you tell me bro?",
                "Well just stop getting killed",
                "'Cause I'm getting P.O'D",
                "It's a yes or a no",
                "Well I'd take that as a no",
                "Ho, ho, ho",
                "I just got pwned",
                "Would you just stop yelling into the microphone?",
                "My guy just died and he made a big groan!",
                "That's 'cause you just fought five guys alone!",

                "Living life in a life of a noob",
                "I rarely use my gun",
                "Living life in a life of a noob",
                "It's fun for everyone",
                "Living life in a life of a noob",
                "I watch the rising sun",
                "Living life in a life of a noob",
                "I'm always on the run",

                "I take a shotgun and a sniper to see",
                "But you just took the best guns from me!",
                "Don't worry buddy! I'll be MVP!",
                "And your highest skill rate is a level 3...",
                "Oh, that don't matter: see, 'cause I'm a natural!",
                "I look into the scope, oh holy mackerel!",
                "You just got blown up by a frag...",
                "Haha! Check it out, I'm getting teabagged!",

                "Living life in a life of a noob",
                "I rarely use my gun",
                "Living life in a life of a noob",
                "It's fun for everyone",
                "Living life in a life of a noob",
                "I watch the rising sun",
                "Living life in a life of a noob",
                "I'm always on the run",

                "Come on friend, we're at the end!",
                "And we're at a base that you can't defend...",
                "You silly goose, you need to get loose!",
                "When I'm uptight, I drink apple juice!",
                "Then you're gonna play just like I do!",
                "That's why I don't take advice from you...",
                "This kid still isn't worth a dime....",
                "Let's sing the chorus one more time!",
                "Oh my god, honestly, do you ever shut up?!",

                "Living life in a life of a noob is quite a hard hardship",
                "Living life in a life of a noob you'll be treated like shit",
                "But I love it!",

                "Living life in a life of a noob",
                "I rarely use my gun (rarely use my guuunn)",
                "Living life in a life of a noob",
                "It's fun for everyone (fun for everyooonnneee)",
                "Living life in a life of a noob",
                "I watch the rising sun (watch the rising suuunn)",
                "Living life in a life of a noob",
                "I'm always on the run (always on the ruuunn)",
                "Living life in a life of a noob (bup, bup, bup, bup)",
                "I rarely use my gun (rarely use my guuunn)",
                "Living life in a life of a noob (bup, bup, bup, bup)",
                "It's fun for everyone (fun for everyooonnneee)",
                "Living life in a life of a noob (bup, bup, bup, bup)",
                "I watch the rising sun (watch the rising suuunn)",
                "Living life in a life of a noob (bup, bup, bup, bup)",
                "I'm always on the run (always on the RUUUUUNNNNN)",

                "Hey!",
                "Are you that guy that made that Halo 3 Rap?",
                "Yeah, that's me",
                "That sucked!"
            }

            if not card.ability.lyric_index then
                card.ability.lyric_index = 1
            end

            local line = lyrics[card.ability.lyric_index]
            card.ability.lyric_index = card.ability.lyric_index + 1
            if card.ability.lyric_index > #lyrics then
                card.ability.lyric_index = 1 -- Loop
            end

            return {
                message = line,
                mult = card.ability.extra.mult,
                colour = G.C.YELLOW
            }
        end
    end
}
SMODS.Spectral {
    key = 'chaotic_seal',
    loc_txt = {
        name = 'Chaotic Seal',
        text = {
            "Give {C:attention}10{} random cards in your hand",
            "a {C:attention}random seal BUT fake{} each."
        }
    },
    atlas = 'coolmod',
    pos = { x = 4, y = 1 },
    cost = 3,
    can_use = function(self, card)
        return #G.hand.cards > 0
    end,
    use = function(self, card)
        local hand_cards = G.hand.cards
        if #hand_cards == 0 then return end

        local num = math.min(10, #hand_cards)
        local chosen = {}
        local seals = {"Gold", "Red", "Blue", "Purple"}

        for i = 1, num do
            local c = pseudorandom_element(hand_cards, pseudoseed('chaoticseal'..i))
            if not chosen[c] then
                chosen[c] = true
                local seal = seals[pseudorandom(pseudoseed('chaoticseal_type'..i), 1, #seals)]
                if c.set_seal then
                    c:set_seal(seal)
                elseif c.ability then
                    c.ability.seal = seal
                end
                c:juice_up()
            end
        end

        G.E_MANAGER:add_event(Event({
            func = function()
                play_sound('spectral_activate')
                return true
            end
        }))
    end
}
SMODS.Back{
    key = "neutral",
    name = "Neutral Deck",
    loc_txt = {
        name = "Neutral Deck",
        text = {
            "Literally Nothing."
        }
    },
    atlas = "coolmod", -- replace with your deck atlas if custom
    pos = {x = 5, y = 1},
}
SMODS.Atlas {
    key = "vegeta",
    path = "vegeta.png",
    px = 71,
    py = 95
}
SMODS.Back{
    name = "9000",
    key = "vegeta",
    atlas = "vegeta",
    pos = {x = 0, y = 0},
    loc_txt = {
        name = "9000",
        text = {"IT'S OVER 9000!"}
    },
    apply = function(self)
        G.E_MANAGER:add_event(Event({
            func = function()
                -- Increase limits
                G.jokers.config.card_limit = 9000
                G.consumeables.config.card_limit = 9000

                -- Add 9000 random playing cards
                for i = 1, 848 do
                    local suit = pseudorandom_element({"Hearts","Spades","Clubs","Diamonds"}, pseudoseed("vegeta_suit"..i))
                    local rank = pseudorandom_element({"2","3","4","5","6","7","8","9","10","J","Q","K","A"}, pseudoseed("vegeta_rank"..i))

                    -- Create the card using built-in helper
                    local card = create_playing_card({
                        rank = rank,
                        suit = suit,
                        area = G.deck
                    })

                    card:add_to_deck()
                    table.insert(G.deck.cards, card)
                end

                G.deck:shuffle()
                print("[9000 Deck] Added 9000 playing cards successfully.")
                return true
            end
        }))
    end
}


SMODS.Atlas {
    key = "cardboard",
    path = "cardboard.png",
    px = 71,
    py = 95
}
-- Cardboard Collection (balanced gameplay chaos)
-- 15 visually identical jokers, each with a different hidden effect.
-- Assumes atlas "cardboard" (cardboard.png) is already available.

if not SMODS then return end

-- small helper to count table entries (safe)
local function tbl_count(t)
    if not t then return 0 end
    local c = 0
    for _ in pairs(t) do c = c + 1 end
    return c
end

-- safe random element
local function safe_random_element(tbl)
    if not tbl or #tbl == 0 then return nil end
    return tbl[math.random(1, #tbl)]
end

-- Helper to safely get hands_played
local function hands_played_safe()
    if G and G.GAME and G.GAME.round_resets and type(G.GAME.round_resets.hands_played) == "number" then
        return G.GAME.round_resets.hands_played
    end
    return 0
end

-- All 15 Cardboard jokers
-- They are intentionally identical in name/description/atlas.
-- Each has a different calculate() effect keyed by number in the key.

-- Template note: using calculate() to return scoring effects when appropriate.
-- Most effects only trigger when context.joker_main is true (normal joker scoring context).

----------------------------------------------------------------
-- Cardboard 1: Flat +2 Mult
----------------------------------------------------------------
SMODS.Joker{
    key = "cardboard_1",
    loc_txt = {
        name = "Cardboard",
        text = {
            "An ordinary piece of cardboard.",
            "Nothing special about it."
        }
    },
    rarity = 2,
    cost = 5,
    atlas = "cardboard",
    config = {},
    calculate = function(self, card, context)
        if context and context.joker_main then
            return { mult = 2 }
        end
    end
}

----------------------------------------------------------------
-- Cardboard 2: Flat +10 Chips
----------------------------------------------------------------
SMODS.Joker{
    key = "cardboard_2",
    loc_txt = {
        name = "Cardboard",
        text = {
            "An ordinary piece of cardboard.",
            "Nothing special about it."
        }
    },
    rarity = 2,
    cost = 5,
    atlas = "cardboard",
    config = {},
    calculate = function(self, card, context)
        if context and context.joker_main then
            return { chips = 10 }
        end
    end
}

----------------------------------------------------------------
-- Cardboard 3: x0.5 Mult if hand is Pair (minor penalty)
----------------------------------------------------------------
SMODS.Joker{
    key = "cardboard_3",
    loc_txt = {
        name = "Cardboard",
        text = {
            "An ordinary piece of cardboard.",
            "Nothing special about it."
        }
    },
    rarity = 2,
    cost = 5,
    atlas = "cardboard",
    config = {},
    calculate = function(self, card, context)
        if context and context.joker_main then
            if context.handname == "Pair" then
                return { x_mult = 0.5 }
            end
        end
    end
}

----------------------------------------------------------------
-- Cardboard 4: Double x_mult on every 4th hand (safe)
----------------------------------------------------------------
SMODS.Joker{
    key = "cardboard_4",
    loc_txt = {
        name = "Cardboard",
        text = {
            "An ordinary piece of cardboard.",
            "Nothing special about it."
        }
    },
    rarity = 2,
    cost = 5,
    atlas = "cardboard",
    config = {},
    calculate = function(self, card, context)
        if context and context.joker_main then
            local hp = hands_played_safe()
            -- only apply on true 4th hands (and skip when 0)
            if hp > 0 and hp % 4 == 0 then
                return { x_mult = 2 }
            end
        end
    end
}

----------------------------------------------------------------
-- Cardboard 5: +25 Chips if first card in scoring_hand is Hearts
----------------------------------------------------------------
SMODS.Joker{
    key = "cardboard_5",
    loc_txt = {
        name = "Cardboard",
        text = {
            "An ordinary piece of cardboard.",
            "Nothing special about it."
        }
    },
    rarity = 2,
    cost = 5,
    atlas = "cardboard",
    config = {},
    calculate = function(self, card, context)
        if context and context.joker_main then
            local sh = context.scoring_hand
            if sh and sh[1] and type(sh[1].is_suit) == "function" and sh[1]:is_suit("Hearts") then
                return { chips = 25 }
            end
        end
    end
}

----------------------------------------------------------------
-- Cardboard 6: +5 Mult if scoring hand contains rank 7
----------------------------------------------------------------
SMODS.Joker{
    key = "cardboard_6",
    loc_txt = {
        name = "Cardboard",
        text = {
            "An ordinary piece of cardboard.",
            "Nothing special about it."
        }
    },
    rarity = 2,
    cost = 5,
    atlas = "cardboard",
    config = {},
    calculate = function(self, card, context)
        if context and context.joker_main then
            for _, v in ipairs(context.scoring_hand or {}) do
                if type(v.get_id) == "function" and v:get_id() == 7 then
                    return { mult = 5 }
                end
            end
        end
    end
}

----------------------------------------------------------------
-- Cardboard 7: +1 Mult per other Joker
----------------------------------------------------------------
SMODS.Joker{
    key = "cardboard_7",
    loc_txt = {
        name = "Cardboard",
        text = {
            "An ordinary piece of cardboard.",
            "Nothing special about it."
        }
    },
    rarity = 2,
    cost = 5,
    atlas = "cardboard",
    config = {},
    calculate = function(self, card, context)
        if context and context.joker_main then
            local jcount = (G and G.jokers and tbl_count(G.jokers.cards)) or 0
            if jcount > 0 then
                return { mult = math.max(0, jcount - 1) }
            end
        end
    end
}

----------------------------------------------------------------
-- Cardboard 8: -1 Mult, +50 Chips (tradeoff)
----------------------------------------------------------------
SMODS.Joker{
    key = "cardboard_8",
    loc_txt = {
        name = "Cardboard",
        text = {
            "An ordinary piece of cardboard.",
            "Nothing special about it."
        }
    },
    rarity = 2,
    cost = 5,
    atlas = "cardboard",
    config = {},
    calculate = function(self, card, context)
        if context and context.joker_main then
            return { chips = 50, mult = -1 }
        end
    end
}

----------------------------------------------------------------
-- Cardboard 9: +10 Mult if fewer than 3 Jokers
----------------------------------------------------------------
SMODS.Joker{
    key = "cardboard_9",
    loc_txt = {
        name = "Cardboard",
        text = {
            "An ordinary piece of cardboard.",
            "Nothing special about it."
        }
    },
    rarity = 2,
    cost = 5,
    atlas = "cardboard",
    config = {},
    calculate = function(self, card, context)
        if context and context.joker_main then
            local jcount = (G and G.jokers and tbl_count(G.jokers.cards)) or 0
            if jcount < 3 then
                return { mult = 10 }
            end
        end
    end
}

----------------------------------------------------------------
-- Cardboard 10: x_mult = 0.25 * discards_used (small scaling)
----------------------------------------------------------------
SMODS.Joker{
    key = "cardboard_10",
    loc_txt = {
        name = "Cardboard",
        text = {
            "An ordinary piece of cardboard.",
            "Nothing special about it."
        }
    },
    rarity = 2,
    cost = 5,
    atlas = "cardboard",
    config = {},
    calculate = function(self, card, context)
        if context and context.joker_main then
            local disc = (G and G.GAME and G.GAME.discards_used) or 0
            return { x_mult = (disc or 0) * 0.25 }
        end
    end
}

----------------------------------------------------------------
-- Cardboard 11: small chance to remove a random Joker and grant +25 Mult
----------------------------------------------------------------
SMODS.Joker{
    key = "cardboard_11",
    loc_txt = {
        name = "Cardboard",
        text = {
            "An ordinary piece of cardboard.",
            "Nothing special about it."
        }
    },
    rarity = 2,
    cost = 5,
    atlas = "cardboard",
    config = {},
    calculate = function(self, card, context)
        if context and context.joker_main then
            -- 5% chance (defensive)
            if math.random() <= 0.05 then
                local pool = (G and G.jokers and G.jokers.cards) or {}
                local target = safe_random_element(pool)
                if target and target ~= self and type(target.start_dissolve) == "function" then
                    -- schedule dissolve after scoring (non-blocking)
                    G.E_MANAGER:add_event(Event({
                        trigger = "after",
                        func = function()
                            if target and type(target.start_dissolve) == "function" then
                                target:start_dissolve()
                            end
                            return true
                        end
                    }))
                    return { mult = 25 }
                end
            end
        end
    end
}

----------------------------------------------------------------
-- Cardboard 12: +10 Mult if deck size is exactly 52
----------------------------------------------------------------
SMODS.Joker{
    key = "cardboard_12",
    loc_txt = {
        name = "Cardboard",
        text = {
            "An ordinary piece of cardboard.",
            "Nothing special about it."
        }
    },
    rarity = 2,
    cost = 5,
    atlas = "cardboard",
    config = {},
    calculate = function(self, card, context)
        if context and context.joker_main then
            local decksize = (G and G.GAME and G.GAME.deck and #G.GAME.deck.cards) or 0
            if decksize == 52 then
                return { mult = 10 }
            end
        end
    end
}

----------------------------------------------------------------
-- Cardboard 13: If scoring hand has >=3 suits, gain a permanent +1 mult (stacking)
----------------------------------------------------------------
SMODS.Joker{
    key = "cardboard_13",
    loc_txt = {
        name = "Cardboard",
        text = {
            "An ordinary piece of cardboard.",
            "Nothing special about it."
        }
    },
    rarity = 2,
    cost = 5,
    atlas = "cardboard",
    config = {},
    calculate = function(self, card, context)
        -- Ensure ability exists
        self.ability = self.ability or {}

        if context and context.joker_main then
            local sh = context.scoring_hand or {}
            local suits = {}

            for _, v in ipairs(sh) do
                if v and v.base and v.base.suit then
                    suits[v.base.suit] = true
                end
            end

            local suitcount = 0
            for _ in pairs(suits) do suitcount = suitcount + 1 end

            if suitcount >= 3 then
                self.ability.perma_mult = (self.ability.perma_mult or 0) + 1
                return {
                    message = "+" .. tostring(self.ability.perma_mult) .. " Mult!",
                    mult_mod = self.ability.perma_mult,
                    colour = G.C.MULT
                }
            end
        end
    end
}


----------------------------------------------------------------
-- Cardboard 14: Small ante-driven temp mult that resets every 5 antes
----------------------------------------------------------------
----------------------------------------------------------------
-- Cardboard 14 (fixed): Small ante-driven temp mult that resets every 5 antes
----------------------------------------------------------------
SMODS.Joker{
    key = "cardboard_14",
    loc_txt = {
        name = "Cardboard",
        text = {
            "An ordinary piece of cardboard.",
            "Nothing special about it."
        }
    },
    rarity = 2,
    cost = 5,
    atlas = "cardboard",
    config = {},
    -- initialize ability so we never get nil
    create = function(self, card)
        card.ability = card.ability or {}
        card.ability.temp_mult = 0
    end,
    calculate = function(self, card, context)
        -- ensure ability always exists
        self.ability = self.ability or {}
        self.ability.temp_mult = self.ability.temp_mult or 0

        if context and context.setting_blind then
            self.ability.temp_mult = self.ability.temp_mult + 1
            local antecount = (G and G.GAME and G.GAME.round_resets and G.GAME.round_resets.ante) or 0
            if antecount > 0 and antecount % 5 == 0 then
                self.ability.temp_mult = 0
            end
        end

        if context and context.joker_main and self.ability.temp_mult > 0 then
            return { mult = self.ability.temp_mult }
        end
    end
}


----------------------------------------------------------------
-- Cardboard 15: Apply one of the other mild effects randomly (small chooser)
----------------------------------------------------------------
SMODS.Joker{
    key = "cardboard_15",
    loc_txt = {
        name = "Cardboard",
        text = {
            "An ordinary piece of cardboard.",
            "Nothing special about it."
        }
    },
    rarity = 2,
    cost = 5,
    atlas = "cardboard",
    config = {},
    calculate = function(self, card, context)
        if context and context.joker_main then
            -- pick one of a small set of safe mild effects
            local pick = math.random(1,5)
            if pick == 1 then
                return { mult = 3 }
            elseif pick == 2 then
                return { chips = 30 }
            elseif pick == 3 then
                return { x_mult = 1.5 }
            elseif pick == 4 then
                return { chips = -10, mult = 1 } -- tiny tradeoff
            else
                return { x_mult = (G and G.GAME and (G.GAME.discards_used or 0) or 0) * 0.1 }
            end
        end
    end
}

-- End of file
SMODS.Tarot{
    key = "slateskin",
    atlas = "slateskin",
    pos = {x = 0, y = 0},
    loc_txt = {
        name = "Slateskin",
        text = {"Turns a random card in your hand into a {C:attention}Stone{} card"}
    },
    can_use = function(self, card)
        return #G.hand.cards > 0
    end,
    use = function(self, card)
        local target = pseudorandom_element(G.hand.cards, pseudoseed("slateskin"))
        if target then
            target:set_ability(G.P_CENTERS["m_stone"])
            return {message = "Hardened!", colour = G.C.GREY}
        else
            sendWarnMessage("Slateskin Tarot not found; skipped creation.")
        end
    end  -- ✅ ends function
}         -- ✅ ends Tarot



-- Noob
SMODS.Joker{
    key = "noob",
    atlas = "forsaken",
    pos = {x = 0, y = 0},
    rarity = 2,
    cost = 7,
    loc_txt = {
        name = "Noob",
        text = {"Has a {C:green}10%{} chance to create a {C:tarot}Slateskin Tarot{}"}
    },
    calculate = function(self, card, context)
        if context.joker_main and pseudorandom("noob") < 0.1 then
            local tarot_center = G.P_CENTERS["c_slateskin"] or G.P_CENTERS["slateskin"]
            if tarot_center then
                local tarot = create_card("Tarot", G.consumeables, nil, nil, nil, nil, tarot_center.key)
                tarot:add_to_deck()
                G.consumeables:emplace(tarot)
                return {message = "Slateskin!", colour = G.C.GREY}
            else
                sendWarnMessage("Slateskin Tarot not found; skipped creation.")
            end
        end
    end
}


-- Elliot
-- Elliot
SMODS.Joker{
    key = "elliot",
    atlas = "forsaken",
    pos = {x = 1, y = 0},
    rarity = 3,
    cost = 10,
    loc_txt = {
        name = "Elliot",
        text = {"Randomly creates one of many fruit or food jokers."}
    },
    calculate = function(self, card, context)
        if context.joker_main then
            local pool = {
                "j_mvan_gros_michel", "j_mvan_icecream", "j_mvan_cavendish",
                "j_mvan_turtlebean", "j_mvan_popcorn", "j_mvan_dietcola",
                "j_mvan_ramen", "j_mvan_papaya", "j_mvan_burntjoker"
            }

            -- pick a random entry from the list
            local pick = pool[math.random(#pool)]
            local center = G.P_CENTERS[pick]

            if center then
                local joker = create_card("Joker", G.jokers, nil, nil, nil, nil, center.key)
                joker:add_to_deck()
                G.jokers:emplace(joker)
                return {message = "Elliot created a Joker!", colour = G.C.PURPLE}
            else
                sendWarnMessage("Elliot: Failed to find joker '" .. tostring(pick) .. "'")
            end
        end
    end
}


-- Shedletsky
SMODS.Joker{
    key = "shedletsky",
    atlas = "forsaken",
    pos = {x = 2, y = 0},
    loc_txt = {name = "Shedletsky", text = {"Gives {C:mult}+0.9 Mult{}"}},
    calculate = function(self, card, context)
        if context.joker_main then return {mult = 0.9} end
    end
}

-- Two Time
-- Two Time
SMODS.Joker{
    key = "two_time",
    atlas = "forsaken",
    pos = {x = 3, y = 0},
    rarity = 3,
    cost = 10,
    loc_txt = {
        name = "Two Time",
        text = {
            "When Blind is selected, destroy the {C:attention}two Jokers{} to the right",
            "and permanently gain {C:mult}2x{} their {C:money}sell value{} as Mult."
        }
    },

    calculate = function(self, card, context)
        if context.setting_blind then
            local jokers = G.jokers and G.jokers.cards
            if not jokers then return end

            local idx
            for i, j in ipairs(jokers) do
                if j == card then idx = i; break end
            end
            if not idx then return end

            local destroyed = {}
            for offset = 1, 2 do
                local target = jokers[idx + offset]
                if target then table.insert(destroyed, target) end
            end

            if #destroyed > 0 then
                local total_value = 0
                for _, j in ipairs(destroyed) do
                    total_value = total_value + (j.sell_cost or 0)
                end

                G.E_MANAGER:add_event(Event({
                    func = function()
                        for _, j in ipairs(destroyed) do
                            j:start_dissolve()
                        end
                        card.ability.perma_mult = (card.ability.perma_mult or 0) + (total_value * 2)
                        sendWarnMessage("Two Time gained +" .. (total_value * 2) .. " Mult!")
                        return true
                    end
                }))
            end
        end

        -- Apply accumulated Mult
        if context.joker_main then
            local mult = card.ability.perma_mult or 0
            if mult > 0 then
                return {mult = mult, message = "+" .. mult .. " Mult"}
            end
        end
    end
}


-- 007n7
-- 007n7
SMODS.Joker{
    key = "007n7",
    atlas = "forsaken",
    pos = {x = 4, y = 0},
    rarity = 3,
    cost = 10,
    loc_txt = {
        name = "007n7",
        text = {
            "Gives {C:mult}+7{} Mult.",
            "At end of round, may {C:attention}duplicate itself{} (max 4 total)."
        }
    },

    calculate = function(self, card, context)
        -- Give +7 Mult during scoring
        if context.joker_main then
            return {mult = 7, message = "+7 Mult!"}
        end

        -- Duplicate itself at end of round (safely)
        if context.end_of_round and not context.blueprint then
            local jokers = G.jokers and G.jokers.cards
            if not jokers then return end

            -- Count existing 007n7s
            local count = 0
            for _, j in ipairs(jokers) do
                if j.ability and j.ability.name == "007n7" then
                    count = count + 1
                end
            end

            -- Limit to 4 copies
            if count < 4 then
                G.E_MANAGER:add_event(Event({
                    func = function()
                        local center = G.P_CENTERS["j_cool_007n7"]
                        if center then
                            local new = create_card("Joker", G.jokers, nil, nil, nil, nil, center.key)
                            new:add_to_deck()
                            G.jokers:emplace(new)
                            sendWarnMessage("007n7 replicated itself!")
                        end
                        return true
                    end
                }))
            end
        end
    end
}


-- Guest 1337
SMODS.Joker{
    key = "guest1337",
    atlas = "forsaken",
    pos = {x = 5, y = 0},
    loc_txt = {
        name = "Guest 1337",
        text = {"Gives {C:mult}+1337 Mult{}", "but disables the next Joker"}
    },
calculate = function(self, card, context)
    if context.joker_main then
        local found_next = nil
        for i, j in ipairs(G.jokers.cards) do
            if j == card and G.jokers.cards[i + 1] then
                found_next = G.jokers.cards[i + 1]
                break
            end
        end
        if found_next then
            found_next.debuff = true
            return {mult = 1337}
        end
    end
end

}
--return {mult = 1337}
-- Builderman
-- Builderman
SMODS.Joker{
    key = "builderman",
    atlas = "forsaken",
    pos = {x = 6, y = 0},
    rarity = 3,
    cost = 10,
    loc_txt = {
        name = "Builderman",
        text = {
            "i couldnt think of anything",
        }
    },

    calculate = function(self, card, context)
        -- Only run once per round (during joker_main phase)
        if context.joker_main then
            local jokers = G.jokers and G.jokers.cards
            if not jokers then return end

            -- Find Builderman's index in the joker lineup
            local index
            for i, j in ipairs(jokers) do
                if j == card then
                    index = i
                    break
                end
            end
            if not index then return end

            -- Pick left or right card (if available)
            local targets = {}
            if jokers[index - 1] then table.insert(targets, jokers[index - 1]) end
            if jokers[index + 1] then table.insert(targets, jokers[index + 1]) end
            if #targets == 0 then return end

            local target = pseudorandom_element(targets, pseudoseed("builderman"))

            -- Increment hit counter
            target.builder_hits = (target.builder_hits or 0) + 1
            local hits = target.builder_hits

            -- Visual message
            G.E_MANAGER:add_event(Event({
                func = function()
                    sendWarnMessage("Builderman hit " .. (target.ability.name or "a Joker") .. " (" .. hits .. "/3)")
                    return true
                end
            }))

            -- Destroy after 3 hits
            if hits >= 3 then
                G.E_MANAGER:add_event(Event({
                    func = function()
                        target:start_dissolve()
                        sendWarnMessage((target.ability.name or "A Joker") .. " was destroyed by Builderman!")
                        return true
                    end
                }))
            end
        end
    end
}


-- Taph
SMODS.Joker{
    key = "taph",
    atlas = "forsaken",
    pos = {x = 7, y = 0},
    loc_txt = {
        name = "Taph",
        text = {"Gives {C:mult}+22 Mult{}", "but destroys a random Joker"}
    },
    calculate = function(self, card, context)
        if context.joker_main then
            if #G.jokers.cards > 1 then
                local rand = pseudorandom_element(G.jokers.cards, pseudoseed("taph"))
                if rand ~= card then rand:start_dissolve() end
            end
            return {mult = 22}
        end
    end
}

-- Dusekkar
SMODS.Joker{
    key = "dusekkar",
    atlas = "forsaken",
    pos = {x = 8, y = 0},
    loc_txt = {
        name = "Dusekkar",
        text = {"Protects a random Joker from destruction"}
    },
    calculate = function(self, card, context)
        if context.end_of_round then
            local rand = pseudorandom_element(G.jokers.cards, pseudoseed("dusekkar"))
            if rand then rand.protected = true end
            return {message = "Protected!", colour = G.C.BLUE}
        end
    end
}

-- Chance
SMODS.Joker{
    key = "chance",
    atlas = "forsaken",
    pos = {x = 9, y = 0},
    loc_txt = {
        name = "Chance",
        text = {"Gives {C:mult}+777{} or {C:red}-777{} Mult (50/50 chance)"}
    },
    calculate = function(self, card, context)
        if context.joker_main then
            if math.random() < 0.5 then
                return {mult = 777, message = "Jackpot!", colour = G.C.GOLD}
            else
                return {mult = -777, message = "Unlucky!", colour = G.C.RED}
            end
        end
    end
}

-- Slasher
SMODS.Joker{
    key = "slasher",
    atlas = "forsaken",
    pos = {x = 10, y = 0},
    loc_txt = {name = "Slasher", text = {"Gives {C:mult}+70 Mult{}", "but disables any Guest Joker"}},
    calculate = function(self, card, context)
        for _, j in ipairs(G.jokers.cards) do
            if j.ability and j.ability.key == "guest1337" then j.disabled = true end
        end
        if context.joker_main then return {mult = 70} end
    end
}

-- c00lkidd
SMODS.Joker{
    key = "c00lkidd",
    atlas = "forsaken",
    pos = {x = 11, y = 0},
    loc_txt = {name = "c00lkidd", text = {"Gives {C:mult}+300 Mult{}", "but disables any 007n7"}},
    calculate = function(self, card, context)
        for _, j in ipairs(G.jokers.cards) do
            if j.ability and j.ability.key == "007n7" then j.disabled = true end
        end
        if context.joker_main then return {mult = 300} end
    end
}

-- John Doe
SMODS.Joker{
    key = "johndoe",
    atlas = "forsaken",
    pos = {x = 12, y = 0},
    loc_txt = {
        name = "John Doe",
        text = {"When Blind is selected, destroy Joker to the left",
                "and permanently add its sell value to this Mult"}
    },
    calculate = function(self, card, context)
        if context.before_blind_select then
            local idx = G.jokers:find_card(card)
            local left = G.jokers.cards[idx - 1]
            if left then
                local val = left.sell_cost or 0
                G.GAME.perma_mult = (G.GAME.perma_mult or 0) + val
                left:start_dissolve()
                return {message = "Silent Kill", colour = G.C.RED}
            end
        end
    end
}

-- 1x1x1x1
SMODS.Joker{
    key = "1x1x1x1",
    atlas = "forsaken",
    pos = {x = 13, y = 0},
    loc_txt = {name = "1x1x1x1", text = {"Gives {C:mult}+1111 Mult{}", "but disables any Shedletsky"}},
    calculate = function(self, card, context)
        for _, j in ipairs(G.jokers.cards) do
            if j.ability and j.ability.key == "shedletsky" then j.disabled = true end
        end
        if context.joker_main then return {mult = 1111} end
    end
}

-- Noli
SMODS.Joker{
    key = "noli",
    atlas = "forsaken",
    pos = {x = 14, y = 0},
    loc_txt = {name = "Noli", text = {"Gives {C:mult}+1100{} or {C:mult}+300{} Mult (random)"}},
    calculate = function(self, card, context)
        if context.joker_main then
            local val = (math.random() < 0.5) and 1100 or 300
            return {mult = val, message = tostring(val).." Mult!", colour = G.C.YELLOW}
        end
    end
}
SMODS.Atlas {
    key = "stuffs",
    path = "stuffs.png",
    px = 71,
    py = 95
}
------------------------------------------------
-- 1. Coffee Break
------------------------------------------------
SMODS.Joker{
    key = "coffee_break",
    atlas = "stuffs",
    pos = {x = 0, y = 0},
    rarity = 1,
    cost = 4,
    loc_txt = {
        name = "Coffee Break",
        text = {"Gain {C:chips}+50 Chips{} if you play fewer than 3 cards in a hand."}
    },
    calculate = function(self, card, context)
        if context.joker_main and context.cards_played and #context.cards_played < 3 then
            return {chips = 50, message = "Caffeine Rush!"}
        end
    end
}

------------------------------------------------
-- 2. Dice Dealer
------------------------------------------------
SMODS.Joker{
    key = "dice_dealer",
    atlas = "stuffs",
    pos = {x = 1, y = 0},
    rarity = 2,
    cost = 6,
    loc_txt = {
        name = "Dice Dealer",
        text = {"Gives random {C:mult}1-6 Mult{} each hand."}
    },
    calculate = function(self, card, context)
        if context.joker_main then
            local roll = math.random(1, 6)
            return {mult = roll, message = "Rolled "..roll.."!"}
        end
    end
}

------------------------------------------------
-- 3. Lucky Penny
------------------------------------------------
SMODS.Joker{
    key = "lucky_penny",
    atlas = "stuffs",
    pos = {x = 2, y = 0},
    rarity = 1,
    cost = 5,
    loc_txt = {
        name = "Lucky Penny",
        text = {"{C:money}$1{} for each Joker you own at end of round."}
    },
    calculate = function(self, card, context)
        if context.end_of_round then
            local j = #G.jokers.cards
            ease_dollars(j)
            return {message = "+"..j.."$"}
        end
    end
}

------------------------------------------------
-- 4. Ghost Card
------------------------------------------------
SMODS.Joker{
    key = "ghost_card",
    atlas = "stuffs",
    pos = {x = 3, y = 0},
    rarity = 2,
    cost = 8,
    loc_txt = {
        name = "Ghost Card",
        text = {"If you play no face cards, gain {C:mult}+8 Mult{} this hand."}
    },
    calculate = function(self, card, context)
        if context.joker_main and context.cards_played then
            for _, c in ipairs(context.cards_played) do
                if c:is_face() then return end
            end
            return {mult = 8, message = "No Faces!"}
        end
    end
}

------------------------------------------------
-- 5. The Intern
------------------------------------------------
SMODS.Joker{
    key = "intern",
    atlas = "stuffs",
    pos = {x = 4, y = 0},
    rarity = 1,
    cost = 3,
    loc_txt = {
        name = "The Intern",
        text = {"Gives {C:mult}+1 Mult{} per hand played this round."}
    },
    calculate = function(self, card, context)
        if context.joker_main then
            local hands = G.GAME.current_round.hands_played or 0
            return {mult = hands, message = "+"..hands.." Mult"}
        end
    end
}

------------------------------------------------
-- 6. The Brick
------------------------------------------------
SMODS.Joker{
    key = "brick",
    atlas = "stuffs",
    pos = {x = 5, y = 0},
    rarity = 1,
    cost = 2,
    loc_txt = {
        name = "The Brick",
        text = {"Nothing happens."}
    }
}

------------------------------------------------
-- 7. Critical Hit
------------------------------------------------
SMODS.Joker{
    key = "critical_hit",
    atlas = "stuffs",
    pos = {x = 6, y = 0},
    rarity = 3,
    cost = 12,
    loc_txt = {
        name = "Critical Hit",
        text = {"5% chance to {C:mult}x5{} total Mult on scoring."}
    },
    calculate = function(self, card, context)
        if context.joker_main and math.random(1,100) <= 5 then
            return {x_mult = 5, message = "CRIT!"}
        end
    end
}

------------------------------------------------
-- 8. Dumpster Fire
------------------------------------------------
SMODS.Joker{
    key = "dumpster_fire",
    atlas = "stuffs",
    pos = {x = 7, y = 0},
    rarity = 2,
    cost = 5,
    loc_txt = {
        name = "Dumpster Fire",
        text = {"Destroys 1 random playing card at end of round.",
                "Gain {C:mult}+10 Mult{} permanently."}
    },
    calculate = function(self, card, context)
        if context.end_of_round then
            local deck = G.playing_cards and G.playing_cards.cards
            if deck and #deck > 0 then
                local c = pseudorandom_element(deck)
                if c then c:start_dissolve() end
                card.ability.perma_mult = (card.ability.perma_mult or 0) + 10
                sendWarnMessage("Dumpster gained +10 Mult!")
            end
        elseif context.joker_main then
            local m = card.ability.perma_mult or 0
            if m > 0 then return {mult = m, message = "+"..m.." Mult"} end
        end
    end
}

------------------------------------------------
-- 9. Speedrunner
------------------------------------------------
SMODS.Joker{
    key = "speedrunner",
    atlas = "stuffs",
    pos = {x = 8, y = 0},
    rarity = 2,
    cost = 7,
    loc_txt = {
        name = "Speedrunner",
        text = {"If you end round in under 20s, gain {C:mult}+15 Mult{} next round."}
    },
    calculate = function(self, card, context)
        if context.end_of_round and G.GAME.round_time and G.GAME.round_time < 20 then
            card.ability.temp_mult = 15
            sendWarnMessage("Speed bonus +15 Mult!")
        elseif context.joker_main then
            if card.ability.temp_mult and card.ability.temp_mult > 0 then
                local m = card.ability.temp_mult
                card.ability.temp_mult = 0
                return {mult = m, message = "+"..m.." Mult"}
            end
        end
    end
}

------------------------------------------------
-- 10. Taxman
------------------------------------------------
SMODS.Joker{
    key = "taxman",
    atlas = "stuffs",
    pos = {x = 9, y = 0},
    rarity = 2,
    cost = 6,
    loc_txt = {
        name = "Taxman",
        text = {"At end of round, lose {C:money}$2{}, gain {C:mult}+10 Mult{} next hand."}
    },
    calculate = function(self, card, context)
        if context.end_of_round then
            ease_dollars(-2)
            card.ability.temp_mult = 10
            sendWarnMessage("Tax Paid!")
        elseif context.joker_main and card.ability.temp_mult then
            local m = card.ability.temp_mult
            card.ability.temp_mult = 0
            return {mult = m, message = "+"..m.." Mult"}
        end
    end
}

------------------------------------------------
-- 11. Card Collector
------------------------------------------------
SMODS.Joker{
    key = "card_collector",
    atlas = "stuffs",
    pos = {x = 10, y = 0},
    rarity = 2,
    cost = 7,
    loc_txt = {
        name = "Card Collector",
        text = {"Gains {C:mult}+2{} Mult for each card in your hand when scoring."}
    },
    calculate = function(self, card, context)
        -- Trigger during main scoring context (joker phase)
        if context.joker_main and context.full_hand and #context.full_hand > 0 then
            local mult_gain = #context.full_hand * 2

            return {
                message = "+" .. tostring(mult_gain) .. " Mult!",
                mult_mod = mult_gain,
                colour = G.C.MULT
            }
        end
    end
}



------------------------------------------------
-- 12. The Glitch
------------------------------------------------
SMODS.Joker{
    key = "the_glitch",
    atlas = "stuffs",
    pos = {x = 11, y = 0},
    rarity = 3,
    cost = 11,
    loc_txt = {
        name = "The Glitch",
        text = {"Each round gives a random bonus or penalty."}
    },
    calculate = function(self, card, context)
        if context.joker_main then
            local roll = math.random(-10, 15)
            if roll >= 0 then
                return {mult = roll, message = "+"..roll.." Mult"}
            else
                return {mult = roll, message = roll.." Mult...", colour = G.C.RED}
            end
        end
    end
}

------------------------------------------------
-- 13. Paper Crown
------------------------------------------------
SMODS.Joker{
    key = "paper_crown",
    atlas = "stuffs",
    pos = {x = 12, y = 0},
    rarity = 1,
    cost = 3,
    loc_txt = {
        name = "Paper Crown",
        text = {"Gain {C:mult}+5 Mult{} if you have no {C:attention}Rare{} Jokers."}
    },
    calculate = function(self, card, context)
        if context.joker_main then
            for _, j in ipairs(G.jokers.cards) do
                if j.config.center.rarity == 3 then return end
            end
            return {mult = 5, message = "No Rares!"}
        end
    end
}

------------------------------------------------
-- 14. The Accountant
------------------------------------------------
SMODS.Joker{
    key = "accountant",
    atlas = "stuffs",
    pos = {x = 13, y = 0},
    rarity = 2,
    cost = 7,
    loc_txt = {
        name = "The Accountant",
        text = {"Gain {C:mult}+1 Mult{} per {C:money}$10{} owned."}
    },
    calculate = function(self, card, context)
        if context.joker_main then
            local cash = G.GAME.dollars or 0
            local mult = math.floor(cash / 10)
            return {mult = mult, message = "+"..mult.." Mult"}
        end
    end
}

------------------------------------------------
-- 15. Rubber Duck
------------------------------------------------
SMODS.Joker{
    key = "rubber_duck",
    atlas = "stuffs",
    pos = {x = 14, y = 0},
    rarity = 1,
    cost = 4,
    loc_txt = {
        name = "Rubber Duck",
        text = {"Just sits there. Occasionally squeaks (5% chance)."}
    },
    calculate = function(self, card, context)
        if context.joker_main and math.random(1,100) <= 5 then
            return {message = "SQUEAK!"}
        end
    end
}
-- First: Register your atlas
-- Register atlas
SMODS.Atlas {
    key = "jehtt",
    path = "jehtt.png",
    px = 34,
    py = 34,
    frames = 1,
    atlas_table = 'ANIMATION_ATLAS'
}

SMODS.Blind {
    name = "One Chip Wonder",
    key = "one_chip",
    atlas = "jehtt",
    pos = { y = 0 },
    dollars = 999,
    mult = 0,
    loc_txt = {
        name = 'naneinf',
        text = {
            "",
        }
    },
    boss = { min = 1, max = 10 },
    boss_colour = HEX('7b542d'),

    apply = function(self)
        -- Save the original required chips so we can restore it
        self._original_req_chips = G.GAME.blind.chips or G.GAME.current_round.chips
        -- Set required chips to 1
        G.GAME.blind.chips = 0.1
        G.GAME.current_round.chips = 0.1
    end,

    disable = function(self)
        -- Restore original chip requirement if available
        if self._original_req_chips then
            G.GAME.blind.chips = self._original_req_chips
            G.GAME.current_round.chips = self._original_req_chips
        end
    end,

    defeat = function(self)
        -- Ensure it resets after defeat too
        if self._original_req_chips then
            G.GAME.blind.chips = self._original_req_chips
            G.GAME.current_round.chips = self._original_req_chips
        end
    end,
}
SMODS.Blind {
    name = "Sonic.exe",
    key = "sonic_exe",
    atlas = "jehtt",
    pos = { y = 1 },
    dollars = 8,
    mult = 2,
    loc_txt = {
        name = "Sonic.exe",
        text = {
            "After 30 seconds, one random Joker",
            "is destroyed permanently."
        }
    },
    boss = { min = 1, max = 10 },
    boss_colour = HEX('7b542d'),

    -- internal timer
    init = function(self)
        self.timer = 0
        self.triggered = false
    end,

    update = function(self, dt)
        if not self.triggered then
            self.timer = self.timer + dt
            if self.timer >= 30 then
                self.triggered = true
                if #G.jokers.cards > 0 then
                    local kill = pseudorandom_element(G.jokers.cards, pseudoseed('sonic_exe'))
                    if kill then
                        G.E_MANAGER:add_event(Event({
                            func = function()
                                play_sound('negative', 1)
                                kill:start_dissolve(nil, true)
                                G.GAME.blind_triggered = true
                                return true
                            end
                        }))
                    end
                end
            end
        end
    end,

    disable = function(self)
        self.timer = 0
        self.triggered = false
    end,

    defeat = function(self)
        self.timer = 0
        self.triggered = false
    end,
}
SMODS.Blind{
    name = "ewsfrsadf",
    key = "ewsfrsadf",
    atlas = "jehtt", -- any small icon you have
    pos = {y = 2 },
    dollars = 3,
    mult = 1,
    loc_txt = {
        name = "ewsfrsadf",
        text = {
            "i put ewsfrsadf into the code",
            "for a scrapped blind but decided",
            "that this is funnier, does absolutely nothing"
        }
    },
    boss = { min = 1, max = 10 },
    boss_colour = HEX('7b542d'),

    update = function(self, dt)
        if G.HUD and G.HUD.chip_text and G.HUD.chip_text.set_text then
            G.HUD.chip_text:set_text("ewsfrsadf")
        end
    end,

    disable = function(self)
        if G.HUD and G.HUD.chip_text and G.HUD.chip_text.set_text then
            G.HUD.chip_text:set_text(tostring(G.GAME.chips or 0))
        end
    end,

    defeat = function(self)
        if G.HUD and G.HUD.chip_text and G.HUD.chip_text.set_text then
            G.HUD.chip_text:set_text(tostring(G.GAME.chips or 0))
        end
    end,
}
SMODS.Blind{
    name = "nothing",
    key = "nothing",
    atlas = "jehtt", -- any small icon you have
    pos = {y = 3},
    dollars = 0,
    mult = -1,
    loc_txt = {
        name = "",
        text = {
            ""
        }
    },
        boss = { min = 1, max = 10 },
    boss_colour = HEX('7b542d'),

    update = function(self, dt)
        if G.HUD and G.HUD.chip_text and G.HUD.chip_text.set_text then
            G.HUD.chip_text:set_text("ewsfrsadf")
        end
    end,

    disable = function(self)
        if G.HUD and G.HUD.chip_text and G.HUD.chip_text.set_text then
            G.HUD.chip_text:set_text(tostring(G.GAME.chips or 0))
        end
    end,

    defeat = function(self)
        if G.HUD and G.HUD.chip_text and G.HUD.chip_text.set_text then
            G.HUD.chip_text:set_text(tostring(G.GAME.chips or 0))
        end
    end,
}
SMODS.Blind{
    key = "salty_spitoon",
    name = "The Salty Spitoon",
    atlas = "jehtt", -- or your chosen atlas
    pos = {y = 4},
    dollars = 6,
    mult = 2,
    loc_txt = {
        name = "The Salty Spitoon",
        text = {
            "Disables all {C:green}Common{} Jokers.",
            "Only the tough ones allowed."
        }
    },
        boss = { min = 1, max = 10 },
    boss_colour = HEX('7b542d'),

    recalc_debuff = function(self)
        for _, card in ipairs(G.jokers.cards) do
            if card and card.ability and card.ability.set == "Joker" then
                local rarity = card.config.center.rarity or 1
                -- 1 = Common, 2 = Uncommon, 3 = Rare, 4 = Legendary, etc.
                if rarity == 1 and not G.GAME.blind.disabled then
                    card:set_debuff(true)
                end
            end
        end
    end,

    disable = function(self)
        for _, card in ipairs(G.jokers.cards) do
            if card.debuff then
                card:set_debuff(false)
            end
        end
    end,

    defeat = function(self)
        for _, card in ipairs(G.jokers.cards) do
            if card.debuff then
                card:set_debuff(false)
            end
        end
    end
}

-- K Blind
SMODS.Blind{
    key = "fuckyou_blind",
    name = "fuck you",
    atlas = "jehtt", -- use your own atlas if different
    pos = { y = 5 },
    dollars = -99,
    mult = 1000,
    loc_txt = {
        name = "fuck you",
        text = {
            "fuck you",
        }
    },
    boss = { min = 1, max = 10 },
    boss_colour = HEX('7b542d'),

    recalc_debuff = function(self)
        -- Disable every card (playing cards + jokers)
        for _, card in ipairs(G.playing_cards or {}) do
            card.debuff = true
        end
        for _, card in ipairs(G.jokers.cards or {}) do
            card.debuff = true
        end
    end,

    disable = function(self)
        -- Restore cards afterward
        for _, card in ipairs(G.playing_cards or {}) do
            card.debuff = false
        end
        for _, card in ipairs(G.jokers.cards or {}) do
            card.debuff = false
        end
    end,

    defeat = function(self)
        -- Just in case: clear debuffs after the blind is beaten
        for _, card in ipairs(G.playing_cards or {}) do
            card.debuff = false
        end
        for _, card in ipairs(G.jokers.cards or {}) do
            card.debuff = false
        end
    end
}
-- Register new atlas for Photochad
SMODS.Atlas {
    key = "joker",
    path = "photochad.png",
    px = 71, -- Standard Joker card size (adjust if needed)
    py = 95
}

-- Photochad Joker Definition
SMODS.Joker {
    key = "photochad",
    name = "Photochad",
    atlas = "joker",
    pos = {x = 0, y = 0},
    rarity = 2,
    cost = 9,
    blueprint_compat = true,
    loc_txt = {
        name = "Photochad",
        text = {
            "First played face card gives {C:mult}X2 Mult{} when scored",
            "and is {C:attention}retriggered{} 2 additional times"
        }
    },
    config = {
        mult = 2,
        retriggers = 2
    },

    calculate = function(self, card, context)
        if context.joker_main then
            return {
                message = "You really think I'd make something like this?"
            }
        end
    end
}